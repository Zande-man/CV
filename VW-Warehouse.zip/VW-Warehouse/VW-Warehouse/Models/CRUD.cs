﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace VW_Warehouse.Models
{
    public class CRUD
    {
        public int id { get; set; }
        public string Fname { get; set; }
        public int Fprice { get; set; }

        public CRUD()
        {
                
        }
    }
}
